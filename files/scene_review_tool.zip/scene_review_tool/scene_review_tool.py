# -*- coding: utf-8 -*-
"""
Scene Review Tool
Ultra-compact scene review tool for Maya 2019-2026
Sequential file review from a specified folder.
Supports .mb and .fbx files.

by e.ov
"""

from __future__ import print_function, absolute_import

import os
import sys

# PySide compatibility (Maya 2019-2026)
try:
    from PySide2 import QtWidgets, QtCore, QtGui
    from shiboken2 import wrapInstance
except ImportError:
    from PySide6 import QtWidgets, QtCore, QtGui
    from shiboken6 import wrapInstance

from maya import cmds
import maya.OpenMayaUI as omui


# ============================================================================
# CONFIGURATION
# ============================================================================

TOOL_NAME = "Scene Review"
TOOL_VERSION = "2.0"
TOOL_AUTHOR = "e.ov"

WINDOW_WIDTH = 175
MAX_FILENAME_LENGTH = 20

# ============================================================================
# COLOR PALETTE
# ============================================================================

CLR_BG_DARK = "#3a3a3a"
CLR_BG_MID = "#444444"
CLR_BG_LIGHT = "#4a4a4a"
CLR_BORDER = "#555555"
CLR_BORDER_HOVER = "#666666"
CLR_TEXT = "#aaaaaa"
CLR_TEXT_DIM = "#666666"
CLR_ACCENT = "#FFA500"

CLR_STATUS_READY_BG = "#383838"
CLR_STATUS_READY_BORDER = "#444444"
CLR_STATUS_READY_TEXT = "#666666"

CLR_STATUS_LOADING_BG = "rgba(255, 68, 68, 0.12)"
CLR_STATUS_LOADING_BORDER = "rgba(255, 68, 68, 0.3)"
CLR_STATUS_LOADING_TEXT = "#FF6666"

CLR_STATUS_REVIEW_BG = "rgba(34, 197, 94, 0.12)"
CLR_STATUS_REVIEW_BORDER = "rgba(34, 197, 94, 0.3)"
CLR_STATUS_REVIEW_TEXT = "#4ADE80"

CLR_STATUS_STOPPED_BG = "rgba(255, 165, 0, 0.12)"
CLR_STATUS_STOPPED_BORDER = "rgba(255, 165, 0, 0.3)"
CLR_STATUS_STOPPED_TEXT = "#FFA500"

CLR_BTN_STOP_BORDER = "rgba(255, 68, 68, 0.5)"
CLR_BTN_STOP_TEXT = "#FF6666"
CLR_BTN_STOP_HOVER = "#FF4444"

CLR_BTN_NEXT_BORDER = "rgba(34, 197, 94, 0.6)"
CLR_BTN_NEXT_TEXT = "#4ADE80"
CLR_BTN_NEXT_HOVER = "#22C55E"


# ============================================================================
# MAYA MAIN WINDOW HELPER
# ============================================================================

def _get_maya_main_window():
    """Get Maya's main window as a QWidget."""
    main_window_ptr = omui.MQtUtil.mainWindow()
    if main_window_ptr is not None:
        if sys.version_info[0] >= 3:
            return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)
        else:
            return wrapInstance(long(main_window_ptr), QtWidgets.QWidget)  # noqa: F821
    return None


# ============================================================================
# STYLESHEETS
# ============================================================================

def _get_main_stylesheet():
    """Main window stylesheet."""
    return """
        QDialog {{
            background-color: {bg};
            color: {text};
            font-size: 11px;
        }}
        QLabel {{
            background: transparent;
            color: {text};
            font-size: 11px;
        }}
        QCheckBox {{
            color: {text_dim};
            font-size: 11px;
            spacing: 4px;
        }}
        QCheckBox::indicator {{
            width: 10px;
            height: 10px;
            border-radius: 1px;
            border: 1px solid {border};
            background: #333333;
        }}
        QCheckBox::indicator:checked {{
            background: {accent};
            border-color: {accent};
        }}
        QCheckBox::indicator:hover {{
            border-color: {border_hover};
        }}
    """.format(
        bg=CLR_BG_DARK,
        text=CLR_TEXT,
        text_dim=CLR_TEXT_DIM,
        border=CLR_BORDER,
        border_hover=CLR_BORDER_HOVER,
        accent=CLR_ACCENT,
    )


def _get_button_stylesheet(primary=False, stop=False, next_btn=False, disabled_look=False):
    """Button stylesheet."""
    if primary:
        border_color = CLR_ACCENT
        text_color = CLR_ACCENT
        hover_bg = CLR_ACCENT
        hover_text = "#1a1a1a"
    elif stop:
        border_color = CLR_BTN_STOP_BORDER
        text_color = CLR_BTN_STOP_TEXT
        hover_bg = CLR_BTN_STOP_HOVER
        hover_text = "#ffffff"
    elif next_btn:
        border_color = CLR_BTN_NEXT_BORDER
        text_color = CLR_BTN_NEXT_TEXT
        hover_bg = CLR_BTN_NEXT_HOVER
        hover_text = "#ffffff"
    else:
        border_color = CLR_BORDER
        text_color = CLR_TEXT
        hover_bg = CLR_BG_LIGHT
        hover_text = CLR_TEXT

    return """
        QPushButton {{
            background-color: {bg};
            border: 1px solid {border};
            border-radius: 2px;
            color: {text};
            padding: 3px 4px;
            font-size: 11px;
        }}
        QPushButton:hover {{
            background-color: {hover_bg};
            border-color: {border_hover};
            color: {hover_text};
        }}
        QPushButton:pressed {{
            background-color: #333333;
        }}
        QPushButton:disabled {{
            opacity: 0.3;
            background-color: {bg};
            color: {text_dim};
        }}
    """.format(
        bg=CLR_BG_MID,
        border=border_color,
        text=text_color,
        hover_bg=hover_bg,
        border_hover=CLR_BORDER_HOVER if not primary and not stop and not next_btn else border_color,
        hover_text=hover_text,
        text_dim=CLR_TEXT_DIM,
    )


def _get_browse_button_stylesheet(has_folder=False):
    """Browse button stylesheet."""
    text_color = CLR_ACCENT if has_folder else CLR_TEXT
    return """
        QPushButton {{
            background-color: {bg};
            border: 1px solid {border};
            border-radius: 2px;
            color: {text};
            padding: 3px 6px;
            font-size: 11px;
            text-align: left;
        }}
        QPushButton:hover {{
            background-color: {hover_bg};
            border-color: {border_hover};
        }}
    """.format(
        bg=CLR_BG_MID,
        border=CLR_BORDER,
        text=text_color,
        hover_bg=CLR_BG_LIGHT,
        border_hover=CLR_BORDER_HOVER,
    )


def _get_toggle_button_stylesheet(active=False):
    """Toggle button stylesheet."""
    if active:
        return """
            QPushButton {{
                background-color: {bg};
                border: 1px solid {accent};
                border-radius: 2px;
                color: {accent};
                padding: 2px 4px;
                font-size: 11px;
                min-height: 14px;
                max-height: 14px;
            }}
            QPushButton:hover {{
                background-color: #555555;
            }}
        """.format(bg=CLR_BG_MID, accent=CLR_ACCENT)
    else:
        return """
            QPushButton {
                background-color: #333333;
                border: 1px solid #444444;
                border-radius: 2px;
                color: #555555;
                padding: 2px 4px;
                font-size: 11px;
                min-height: 14px;
                max-height: 14px;
            }
            QPushButton:hover {
                background-color: #3a3a3a;
                color: #777777;
                border-color: #555555;
            }
        """


def _get_status_badge_stylesheet(status="ready"):
    """Status badge stylesheet."""
    if status == "loading":
        bg = CLR_STATUS_LOADING_BG
        border = CLR_STATUS_LOADING_BORDER
        text = CLR_STATUS_LOADING_TEXT
    elif status == "review":
        bg = CLR_STATUS_REVIEW_BG
        border = CLR_STATUS_REVIEW_BORDER
        text = CLR_STATUS_REVIEW_TEXT
    elif status == "stopped":
        bg = CLR_STATUS_STOPPED_BG
        border = CLR_STATUS_STOPPED_BORDER
        text = CLR_STATUS_STOPPED_TEXT
    else:  # ready
        bg = CLR_STATUS_READY_BG
        border = CLR_STATUS_READY_BORDER
        text = CLR_STATUS_READY_TEXT

    return """
        QLabel {{
            background-color: {bg};
            border: 1px solid {border};
            border-radius: 2px;
            color: {text};
            padding: 2px 10px;
            font-size: 10px;
            font-weight: bold;
        }}
    """.format(bg=bg, border=border, text=text)


def _get_help_button_stylesheet():
    """Help button stylesheet."""
    return """
        QPushButton {{
            background: transparent;
            border: 1px solid {border};
            border-radius: 2px;
            color: #777777;
            font-size: 9px;
        }}
        QPushButton:hover {{
            border-color: {accent};
            color: {accent};
        }}
    """.format(border=CLR_BORDER, accent=CLR_ACCENT)


def _get_progress_bar_stylesheet():
    """Progress bar stylesheet."""
    return """
        QProgressBar {{
            background-color: #2a2a2a;
            border: none;
            border-radius: 1px;
            height: 2px;
            text-align: center;
        }}
        QProgressBar::chunk {{
            background-color: {accent};
            border-radius: 1px;
        }}
    """.format(accent=CLR_ACCENT)


# ============================================================================
# HELP DIALOG
# ============================================================================

class HelpDialog(QtWidgets.QDialog):
    """Help dialog window."""

    def __init__(self, parent=None):
        super(HelpDialog, self).__init__(parent)
        self.setWindowTitle("About — Scene Review")
        self.setFixedWidth(280)
        self.setStyleSheet(_get_main_stylesheet())
        self._init_ui()

    def _init_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        # Header section (centered)
        header_text = """
<div style="text-align: center;">
<h2 style="color: #FFA500; margin: 0;">Scene Review Tool</h2>
<p style="color: #888; margin: 4px 0;">version {version}</p>
<p style="color: #aaa; margin: 8px 0;">Sequential scene file reviewer for Maya.<br>Supports .mb, .ma and .fbx files.</p>
</div>
<hr style="border: none; border-top: 1px solid #484848; margin: 10px 0;">
""".format(version=TOOL_VERSION)

        header_label = QtWidgets.QLabel(header_text)
        header_label.setWordWrap(True)
        header_label.setTextFormat(QtCore.Qt.RichText)
        header_label.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(header_label)

        # Help content
        help_text = """
<p><b style="color: #ccc;">WORKFLOW</b></p>
<ol style="color: #aaa; margin-left: -20px;">
<li>Click <b>Browse</b> to select folder</li>
<li>Toggle file types (.mb / .ma / .fbx)</li>
<li>Enable <b>Include subfolders</b> if needed</li>
<li>Click <b>Start</b> to load first file</li>
<li>Review scene, click <b>Next</b> for next file</li>
<li>Click <b>Stop</b> to pause</li>
</ol>

<p><b style="color: #ccc;">STATUS</b></p>
<ul style="color: #aaa; margin-left: -20px;">
<li><span style="color: #666;">Ready</span> — waiting to start</li>
<li><span style="color: #FF6666;">Loading</span> — opening file</li>
<li><span style="color: #4ADE80;">Review</span> — file ready for review</li>
<li><span style="color: #FFA500;">Stopped</span> — paused or done</li>
</ul>

<p><b style="color: #ccc;">NOTES</b></p>
<ul style="color: #aaa; margin-left: -20px;">
<li>Files sorted alphabetically</li>
<li>Failed files create error log</li>
<li>Hover filename for full path</li>
</ul>
"""

        help_label = QtWidgets.QLabel(help_text)
        help_label.setWordWrap(True)
        help_label.setTextFormat(QtCore.Qt.RichText)
        layout.addWidget(help_label)

        # Credits section (centered, clickable links)
        credits_text = """
<hr style="border: none; border-top: 1px solid #484848; margin: 10px 0;">
<div style="text-align: center;">
<p style="color: #888; margin: 4px 0;">by <b style="color: #FFA500;">{author}</b></p>
<p style="color: #888; margin: 4px 0;">Contact: <a href="mailto:e.ov@mail.ru" style="color: #FFA500; text-decoration: none;">e.ov@mail.ru</a></p>
<p style="color: #888; margin: 4px 0;">Telegram: <a href="https://t.me/eov_animation" style="color: #FFA500; text-decoration: none;">@eov_animation</a></p>
</div>
""".format(author=TOOL_AUTHOR)

        credits_label = QtWidgets.QLabel(credits_text)
        credits_label.setWordWrap(True)
        credits_label.setTextFormat(QtCore.Qt.RichText)
        credits_label.setOpenExternalLinks(True)
        credits_label.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(credits_label)

        # OK button
        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.addStretch()
        ok_btn = QtWidgets.QPushButton("OK")
        ok_btn.setFixedWidth(60)
        ok_btn.setStyleSheet(_get_button_stylesheet())
        ok_btn.clicked.connect(self.accept)
        btn_layout.addWidget(ok_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)


# ============================================================================
# MAIN WINDOW
# ============================================================================

class SceneReviewTool(QtWidgets.QDialog):
    """Main Scene Review Tool window."""

    def __init__(self, parent=None):
        super(SceneReviewTool, self).__init__(parent)

        # State
        self.folder_path = ""
        self.folder_name = ""
        self.file_list = []
        self.current_index = -1
        self.current_file_path = ""
        self.is_review_active = False
        self.include_subfolders = False
        self.file_types = set()  # Set of enabled types: mb, ma, fbx — empty by default

        # Window setup
        self.setWindowTitle(TOOL_NAME)
        self.setFixedWidth(WINDOW_WIDTH)
        self.setWindowFlags(
            QtCore.Qt.Window |
            QtCore.Qt.WindowCloseButtonHint
        )
        self.setStyleSheet(_get_main_stylesheet())

        self._init_ui()
        self._update_button_states()

    def _init_ui(self):
        """Initialize the UI."""
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(4)

        # === Title bar ===
        title_layout = QtWidgets.QHBoxLayout()
        title_layout.setSpacing(4)

        title_label = QtWidgets.QLabel(TOOL_NAME)
        title_label.setStyleSheet("color: {}; font-weight: bold; font-size: 11px;".format(CLR_ACCENT))
        title_layout.addWidget(title_label)

        title_layout.addStretch()

        self.help_btn = QtWidgets.QPushButton("?")
        self.help_btn.setFixedSize(15, 15)
        self.help_btn.setStyleSheet(_get_help_button_stylesheet())
        self.help_btn.clicked.connect(self._show_help)
        title_layout.addWidget(self.help_btn)

        layout.addLayout(title_layout)

        # === Browse section ===
        self.browse_btn = QtWidgets.QPushButton("📁  Browse...")
        self.browse_btn.setStyleSheet(_get_browse_button_stylesheet())
        self.browse_btn.clicked.connect(self._browse_folder)
        layout.addWidget(self.browse_btn)

        self.subfolder_checkbox = QtWidgets.QCheckBox("Include subfolders")
        self.subfolder_checkbox.stateChanged.connect(self._on_subfolder_changed)
        layout.addWidget(self.subfolder_checkbox)

        layout.addWidget(self._create_separator())

        # === File type toggle buttons ===
        radio_layout = QtWidgets.QHBoxLayout()
        radio_layout.setSpacing(2)

        self.toggle_mb = QtWidgets.QPushButton(".mb")
        self.toggle_ma = QtWidgets.QPushButton(".ma")
        self.toggle_fbx = QtWidgets.QPushButton(".fbx")

        for btn in [self.toggle_mb, self.toggle_ma, self.toggle_fbx]:
            btn.setCheckable(True)
            btn.setChecked(False)
            btn.setFixedHeight(18)
            radio_layout.addWidget(btn)

        self.toggle_mb.clicked.connect(lambda: self._toggle_file_type("mb"))
        self.toggle_ma.clicked.connect(lambda: self._toggle_file_type("ma"))
        self.toggle_fbx.clicked.connect(lambda: self._toggle_file_type("fbx"))

        self._update_toggle_styles()
        layout.addLayout(radio_layout)

        layout.addWidget(self._create_separator())

        # === Info section ===
        # Progress row
        progress_layout = QtWidgets.QHBoxLayout()
        progress_label = QtWidgets.QLabel("Progress")
        progress_label.setStyleSheet("color: {};".format(CLR_TEXT_DIM))
        progress_layout.addWidget(progress_label)
        progress_layout.addStretch()
        self.progress_value = QtWidgets.QLabel("0/0")
        self.progress_value.setStyleSheet("color: {};".format(CLR_TEXT))
        progress_layout.addWidget(self.progress_value)
        layout.addLayout(progress_layout)

        # Progress bar
        self.progress_bar = QtWidgets.QProgressBar()
        self.progress_bar.setFixedHeight(2)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet(_get_progress_bar_stylesheet())
        self.progress_bar.setValue(0)
        layout.addWidget(self.progress_bar)

        # File row
        file_layout = QtWidgets.QHBoxLayout()
        file_label = QtWidgets.QLabel("File")
        file_label.setStyleSheet("color: {};".format(CLR_TEXT_DIM))
        file_layout.addWidget(file_label)
        file_layout.addStretch()
        self.file_value = QtWidgets.QLabel("—")
        self.file_value.setStyleSheet("color: {};".format(CLR_TEXT))
        file_layout.addWidget(self.file_value)
        layout.addLayout(file_layout)

        # Status badge
        status_layout = QtWidgets.QHBoxLayout()
        status_layout.addStretch()
        self.status_badge = QtWidgets.QLabel("READY")
        self.status_badge.setAlignment(QtCore.Qt.AlignCenter)
        self.status_badge.setStyleSheet(_get_status_badge_stylesheet("ready"))
        status_layout.addWidget(self.status_badge)
        status_layout.addStretch()
        layout.addLayout(status_layout)

        layout.addWidget(self._create_separator())

        # === Control buttons ===
        controls_layout = QtWidgets.QHBoxLayout()
        controls_layout.setSpacing(3)

        self.start_btn = QtWidgets.QPushButton("Start")
        self.next_btn = QtWidgets.QPushButton("Next")
        self.stop_btn = QtWidgets.QPushButton("Stop")

        self.start_btn.setStyleSheet(_get_button_stylesheet(primary=True))
        self.next_btn.setStyleSheet(_get_button_stylesheet(next_btn=True))
        self.stop_btn.setStyleSheet(_get_button_stylesheet(stop=True))

        self.start_btn.clicked.connect(self._on_start)
        self.next_btn.clicked.connect(self._on_next)
        self.stop_btn.clicked.connect(self._on_stop)

        controls_layout.addWidget(self.start_btn)
        controls_layout.addWidget(self.next_btn)
        controls_layout.addWidget(self.stop_btn)
        layout.addLayout(controls_layout)

        # Copy buttons
        copy_layout = QtWidgets.QHBoxLayout()
        copy_layout.setSpacing(3)

        self.copy_name_btn = QtWidgets.QPushButton("Copy Name")
        self.copy_path_btn = QtWidgets.QPushButton("Copy Path")

        self.copy_name_btn.setStyleSheet(_get_button_stylesheet())
        self.copy_path_btn.setStyleSheet(_get_button_stylesheet())

        self.copy_name_btn.clicked.connect(self._copy_name)
        self.copy_path_btn.clicked.connect(self._copy_path)

        copy_layout.addWidget(self.copy_name_btn)
        copy_layout.addWidget(self.copy_path_btn)
        layout.addLayout(copy_layout)

    def _create_separator(self):
        """Create a horizontal separator line."""
        sep = QtWidgets.QFrame()
        sep.setFrameShape(QtWidgets.QFrame.HLine)
        sep.setFixedHeight(1)
        sep.setStyleSheet("background-color: #484848;")
        return sep

    def _update_toggle_styles(self):
        """Update toggle button styles based on selection."""
        self.toggle_mb.setStyleSheet(_get_toggle_button_stylesheet("mb" in self.file_types))
        self.toggle_ma.setStyleSheet(_get_toggle_button_stylesheet("ma" in self.file_types))
        self.toggle_fbx.setStyleSheet(_get_toggle_button_stylesheet("fbx" in self.file_types))

    def _toggle_file_type(self, file_type):
        """Toggle file type on/off."""
        if file_type in self.file_types:
            self.file_types.discard(file_type)
        else:
            self.file_types.add(file_type)
        
        # Sync button checked state
        self.toggle_mb.setChecked("mb" in self.file_types)
        self.toggle_ma.setChecked("ma" in self.file_types)
        self.toggle_fbx.setChecked("fbx" in self.file_types)
        
        self._update_toggle_styles()
        if self.folder_path:
            self._reset_review()
            self._scan_files()
            self._update_button_states()

    def _browse_folder(self):
        """Open folder browser dialog."""
        folder = QtWidgets.QFileDialog.getExistingDirectory(
            self,
            "Select Folder",
            self.folder_path or os.path.expanduser("~")
        )
        if folder:
            self.folder_path = folder
            self.folder_name = os.path.basename(folder)

            # Update browse button
            display_name = self.folder_name
            if len(display_name) > 15:
                display_name = display_name[:12] + "..."
            self.browse_btn.setText("📁  " + display_name)
            self.browse_btn.setStyleSheet(_get_browse_button_stylesheet(has_folder=True))
            self.browse_btn.setToolTip(folder)

            self._reset_review()
            self._scan_files()
            self._update_button_states()
            
            # Force UI refresh
            self.progress_value.repaint()

    def _on_subfolder_changed(self, state):
        """Handle subfolder checkbox change."""
        self.include_subfolders = state == QtCore.Qt.Checked
        if self.folder_path:
            self._reset_review()
            self._scan_files()
            self._update_button_states()

    def _scan_files(self):
        """Scan folder for scene files."""
        self.file_list = []

        if not self.folder_path or not os.path.exists(self.folder_path):
            return

        # Build valid extensions from enabled types
        if not self.file_types:
            return
        valid_ext = tuple(".{}".format(t) for t in self.file_types)

        if self.include_subfolders:
            folder_files = {}
            for root, dirs, files in os.walk(self.folder_path):
                dirs.sort()
                scene_files = []
                for f in files:
                    if f.lower().endswith(valid_ext):
                        scene_files.append(os.path.join(root, f))
                if scene_files:
                    scene_files.sort(key=lambda x: os.path.basename(x).lower())
                    folder_files[root] = scene_files

            for folder in sorted(folder_files.keys()):
                self.file_list.extend(folder_files[folder])
        else:
            files = os.listdir(self.folder_path)
            for f in files:
                if f.lower().endswith(valid_ext):
                    self.file_list.append(os.path.join(self.folder_path, f))
            self.file_list.sort(key=lambda x: os.path.basename(x).lower())

        # Update progress display
        total = len(self.file_list)
        self.progress_value.setText("0/{}".format(total))
        self.progress_value.setStyleSheet(
            "color: {};".format(CLR_ACCENT if total > 0 else CLR_TEXT)
        )
        self.progress_bar.setMaximum(max(total, 1))
        self.progress_bar.setValue(0)

        if total == 0:
            self._set_status("ready")

    def _reset_review(self):
        """Reset review state."""
        self.current_index = -1
        self.current_file_path = ""
        self.is_review_active = False
        self.file_list = []

        self.progress_value.setText("0/0")
        self.progress_value.setStyleSheet("color: {};".format(CLR_TEXT))
        self.progress_bar.setValue(0)
        self.file_value.setText("—")
        self.file_value.setToolTip("")
        self._set_status("ready")
        self.start_btn.setText("Start")

    def _update_button_states(self):
        """Update button enabled states."""
        has_folder = bool(self.folder_path)
        has_files = len(self.file_list) > 0
        has_current_file = bool(self.current_file_path)
        is_last_file = self.current_index >= len(self.file_list) - 1

        # Start/Continue
        can_start = has_folder and has_files and not self.is_review_active
        if self.current_index >= len(self.file_list) - 1 and self.current_index != -1:
            can_start = False
        self.start_btn.setEnabled(can_start)

        # Next
        self.next_btn.setEnabled(self.is_review_active and not is_last_file)

        # Stop
        self.stop_btn.setEnabled(self.is_review_active)

        # Copy buttons
        self.copy_name_btn.setEnabled(has_current_file)
        self.copy_path_btn.setEnabled(has_current_file)

    def _set_status(self, status):
        """Set status badge."""
        labels = {
            "ready": "READY",
            "loading": "LOADING",
            "review": "REVIEW",
            "stopped": "STOPPED",
        }
        self.status_badge.setText(labels.get(status, "READY"))
        self.status_badge.setStyleSheet(_get_status_badge_stylesheet(status))

    def _truncate_filename(self, filename):
        """Truncate filename for display."""
        if len(filename) <= MAX_FILENAME_LENGTH:
            return filename
        name, ext = os.path.splitext(filename)
        available = MAX_FILENAME_LENGTH - len(ext) - 3
        if available > 0:
            return name[:available] + "..." + ext
        return filename[:MAX_FILENAME_LENGTH - 3] + "..."

    def _on_start(self):
        """Handle Start/Continue button."""
        if self.current_index == -1:
            self.current_index = 0
        self.is_review_active = True
        self.start_btn.setText("Start")
        self._load_current_file()

    def _on_next(self):
        """Handle Next button."""
        if self.current_index < len(self.file_list) - 1:
            self.current_index += 1
            self._load_current_file()

    def _on_stop(self):
        """Handle Stop button."""
        self.is_review_active = False
        self._set_status("stopped")
        self.start_btn.setText("Continue")
        self._update_button_states()

    def _load_current_file(self):
        """Load the current file."""
        if self.current_index < 0 or self.current_index >= len(self.file_list):
            return

        file_path = self.file_list[self.current_index]
        filename = os.path.basename(file_path)

        # Update UI - Loading state
        self._set_status("loading")

        # Update progress
        current = self.current_index + 1
        total = len(self.file_list)
        self.progress_value.setText("{}/{}".format(current, total))
        self.progress_value.setStyleSheet("color: {};".format(CLR_ACCENT))
        self.progress_bar.setValue(current)

        # Update filename
        display_name = self._truncate_filename(filename)
        self.file_value.setText(display_name)
        self.file_value.setToolTip(file_path)

        # Disable buttons during load
        self.next_btn.setEnabled(False)
        self.stop_btn.setEnabled(False)
        self.copy_name_btn.setEnabled(False)
        self.copy_path_btn.setEnabled(False)

        # Force UI refresh
        QtWidgets.QApplication.processEvents()

        # Open file
        success = self._open_file(file_path)

        if success:
            self.current_file_path = file_path
            self._set_status("review")
        else:
            self._create_error_log(file_path)
            # Try next file
            if self.current_index < len(self.file_list) - 1:
                self.current_index += 1
                self._load_current_file()
                return
            else:
                self.current_file_path = ""
                self.is_review_active = False
                self._set_status("stopped")

        self._update_button_states()

    def _open_file(self, file_path):
        """Open a Maya scene file."""
        try:
            ext = os.path.splitext(file_path)[1].lower()
            if ext == ".mb":
                file_type = "mayaBinary"
            elif ext == ".ma":
                file_type = "mayaAscii"
            elif ext == ".fbx":
                file_type = "FBX"
            else:
                return False

            cmds.file(
                file_path,
                open=True,
                force=True,
                type=file_type,
                ignoreVersion=True,
                prompt=False
            )
            return True

        except Exception as e:
            cmds.warning("Failed to open: {}\n{}".format(file_path, str(e)))
            return False

    def _create_error_log(self, file_path):
        """Create error log for failed file."""
        try:
            folder = os.path.dirname(file_path)
            filename = os.path.basename(file_path)
            name_without_ext = os.path.splitext(filename)[0]
            log_path = os.path.join(folder, name_without_ext + "_error.txt")

            error_info = [
                "Scene Review Tool - Error Log",
                "=" * 50,
                "",
                "File: {}".format(filename),
                "Path: {}".format(file_path),
                "",
                "Status: File failed to open",
                "",
                "Possible causes:",
                "- File may be corrupted",
                "- File from newer Maya version",
                "- Unsupported plugins or nodes",
                "- Incompatible references",
                "",
                "Maya Version: {}".format(cmds.about(version=True)),
            ]

            with open(log_path, "w") as f:
                f.write("\n".join(error_info))

            cmds.warning("Error log: {}".format(log_path))

        except Exception as e:
            cmds.warning("Failed to create error log: {}".format(str(e)))

    def _copy_name(self):
        """Copy current filename to clipboard."""
        if self.current_file_path:
            filename = os.path.basename(self.current_file_path)
            clipboard = QtWidgets.QApplication.clipboard()
            clipboard.setText(filename)
            cmds.inViewMessage(
                amg="<span style='color:#88ff88'>Copied: </span>{}".format(filename),
                pos="midCenter",
                fade=True,
                fadeStayTime=1000
            )

    def _copy_path(self):
        """Copy current file path to clipboard."""
        if self.current_file_path:
            clipboard = QtWidgets.QApplication.clipboard()
            clipboard.setText(self.current_file_path)
            cmds.inViewMessage(
                amg="<span style='color:#88ff88'>Copied path</span>",
                pos="midCenter",
                fade=True,
                fadeStayTime=1000
            )

    def _show_help(self):
        """Show help dialog."""
        dialog = HelpDialog(self)
        dialog.exec_()


# ============================================================================
# ENTRY POINT
# ============================================================================

_scene_review_window = None


def show():
    """Show Scene Review Tool."""
    global _scene_review_window

    try:
        _scene_review_window.close()
        _scene_review_window.deleteLater()
    except Exception:
        pass

    maya_win = _get_maya_main_window()
    _scene_review_window = SceneReviewTool(parent=maya_win)
    _scene_review_window.show()

    print("# Scene Review Tool: UI opened #")
    return _scene_review_window


if __name__ == "__main__":
    show()
