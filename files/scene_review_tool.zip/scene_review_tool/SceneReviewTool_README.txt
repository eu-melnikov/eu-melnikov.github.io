Scene Review Tool — Maya 2019+
------------------------------

A tool for sequentially reviewing Maya scene files (.mb, .ma, .fbx)
from a selected folder. Designed for reviewing large numbers of files
without opening each one manually.

Great for streaming through incoming outsource work or any batch review.


WORKFLOW
--------
1. Select a folder
2. Choose whether to include subfolders
3. Select the file format to review (.mb / .ma / .fbx)
4. Click Start
5. Next — Next — Next — Next...
6. Click Stop whenever you're done

Each file is opened exactly once. You will never lose track of what
you've already reviewed and what's still waiting.


FEATURES
--------
- Compact UI — takes up minimal screen space
- Supports .mb, .ma, .fbx formats
- Subfolder support (optional)
- Maya 2019+
