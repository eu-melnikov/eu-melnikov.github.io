Maya Persp Camera History — Maya 2019+
---------------------------------------

A small script that adds Undo/Redo history for the Persp camera in Maya.

The standard Maya hotkeys [ and ] stop working when the camera is moved
by scripts or other tools. This script tracks ALL camera changes — from
both mouse and scripts — and lets you step through the history using
buttons on your shelf.


FEATURES
--------
- Tracks every Persp camera change regardless of source
- History of up to 50 positions
- Undo / Redo via convenient shelf buttons
- Runs silently in the background — zero performance impact


WHEN IT'S USEFUL
----------------
- Snap to object
- Look-at controllers
- Auto-positioning scripts
- Camera angle experiments
- Accidental camera jumps you can't undo with [ ]


INSTALLATION
------------
1. Copy both files into your Maya scripts folder
2. Restart Maya
3. Create two shelf buttons (Undo / Redo) — done!
