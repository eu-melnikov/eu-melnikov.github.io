# -*- coding: utf-8 -*-
import maya.cmds as cmds
import maya.utils as mu

# Global variables
PERSP_CAMERA_HISTORY = []
PERSP_HISTORY_INDEX = -1
PERSP_LAST_POSITION = None
PERSP_MANUAL_RESTORE = False

def store_persp_position(*args):
    """Stores current persp camera position in history"""
    global PERSP_CAMERA_HISTORY, PERSP_HISTORY_INDEX, PERSP_LAST_POSITION, PERSP_MANUAL_RESTORE
    
    # Skip recording if this is Undo/Redo restore
    if PERSP_MANUAL_RESTORE:
        PERSP_MANUAL_RESTORE = False
        PERSP_LAST_POSITION = {
            'translate': cmds.getAttr('persp.translate')[0],
            'rotate': cmds.getAttr('persp.rotate')[0]
        }
        return
    
    current_pos = {
        'translate': cmds.getAttr('persp.translate')[0],
        'rotate': cmds.getAttr('persp.rotate')[0]
    }
    
    # Check if position changed
    if PERSP_LAST_POSITION is not None:
        t_changed = current_pos['translate'] != PERSP_LAST_POSITION['translate']
        r_changed = current_pos['rotate'] != PERSP_LAST_POSITION['rotate']
        
        if not t_changed and not r_changed:
            return
    
    # Trim history if not at the end
    if PERSP_HISTORY_INDEX < len(PERSP_CAMERA_HISTORY) - 1:
        PERSP_CAMERA_HISTORY = PERSP_CAMERA_HISTORY[:PERSP_HISTORY_INDEX + 1]
    
    PERSP_CAMERA_HISTORY.append(current_pos)
    PERSP_HISTORY_INDEX = len(PERSP_CAMERA_HISTORY) - 1
    PERSP_LAST_POSITION = current_pos
    
    # Limit history to 50 positions
    if len(PERSP_CAMERA_HISTORY) > 50:
        PERSP_CAMERA_HISTORY.pop(0)
        PERSP_HISTORY_INDEX -= 1

def setup_persp_history():
    """Initialize persp camera history system"""
    cmds.scriptJob(event=['idle', store_persp_position], permanent=True)
    store_persp_position()
    print("Persp camera history tracking enabled (idle mode)")

mu.executeDeferred(setup_persp_history)