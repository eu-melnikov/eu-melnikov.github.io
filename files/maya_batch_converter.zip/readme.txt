# Maya Batch Converter

A professional tool for batch conversion of Maya scene files between .ma, .mb, and .fbx formats.

## Installation

Copy `maya_batch_converter.py` to your Maya scripts folder:

```
C:/Users/<username>/Documents/maya/scripts/
```

## Launch Commands

### First Launch (all Maya versions)

```python
import maya_batch_converter; maya_batch_converter.show()
```

### With Module Reload

**Maya 2019-2020 (Python 2.7):**

```python
import maya_batch_converter; reload(maya_batch_converter); maya_batch_converter.show()
```

**Maya 2022-2026 (Python 3.x):**

```python
import importlib; import maya_batch_converter; importlib.reload(maya_batch_converter); maya_batch_converter.show()
```

## Features

- Batch convert between MA/MB/FBX formats
- FPS preservation from source files
- Recursive folder processing
- Incremental file naming
- Progress tracking and statistics
- Compatible with Maya 2019-2026

## Author

**e.melnikov**

- Email: emelnikov1973@gmail.com
- Telegram: https://t.me/eov_animation

© 2026
