BoneAnim Combo — Maya 2019+
---------------------------

A Maya tool that automatically merges multiple animation files into
a single continuous sequence.

Built out of a real production need — sharing it in case it saves
someone else the same headache.

Useful when working with large animation libraries where clips need
to be combined into one unbroken sequence.


INSTALLATION
------------
Copy the code to your shelf. Make sure Python mode is selected.
Maya 2019+.
