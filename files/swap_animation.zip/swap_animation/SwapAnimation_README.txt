Swap Animation — Maya 2019+
--------------------------

Swaps animation data between two objects on a selected timeline range.
Everything outside the selected range stays untouched.


WHY YOU MIGHT NEED THIS
-----------------------
- Fixing mocap — when tracks got mixed up between bones
- Timing experiments — quickly see how it looks if character A does
  what character B was doing
- Cycle work — rearrange animation phases between objects


HOW TO USE
----------
1. Select 2 objects
2. Select a range on the timeline (Shift+drag) or keys in Graph Editor
3. Run swap_animation()


FEATURES
--------
- Works with translate, rotate, scale
- Automatically sets boundary keys so animation doesn't drift
- Supports Undo (Ctrl+Z)
- Maya 2019+ / Python 2.7


INSTALLATION
------------
Copy the code into Script Editor (Python tab) or add it to your shelf.
