# -*- coding: utf-8 -*-
import maya.cmds as cmds

ATTRS = ["tx", "ty", "tz", "rx", "ry", "rz", "sx", "sy", "sz"]


def get_selected_range():
    selected_keys = cmds.keyframe(q=True, sl=True)
    if selected_keys:
        return min(selected_keys), max(selected_keys)
    
    timeline_range = cmds.timeControl("timeControl1", q=True, rangeArray=True)
    if timeline_range and len(timeline_range) == 2:
        start, end = timeline_range[0], timeline_range[1] - 1
        if end > start:
            return float(start), float(end)
    
    return None, None


def get_keys_in_range(obj, attr, start, end):
    full_attr = "{}.{}".format(obj, attr)
    keys = cmds.keyframe(full_attr, q=True, t=(start, end))
    return keys if keys else []


def set_boundary_key(obj, attr, frame):
    full_attr = "{}.{}".format(obj, attr)
    
    if not cmds.listConnections(full_attr, type="animCurve"):
        return False
    
    val = cmds.getAttr(full_attr, t=frame)
    cmds.setKeyframe(full_attr, t=frame, v=val)
    return True


def swap_attr_in_range(obj_a, obj_b, attr, start, end):
    attr_a = "{}.{}".format(obj_a, attr)
    attr_b = "{}.{}".format(obj_b, attr)
    
    has_anim_a = cmds.listConnections(attr_a, type="animCurve")
    has_anim_b = cmds.listConnections(attr_b, type="animCurve")
    
    if not has_anim_a and not has_anim_b:
        return
    
    if has_anim_a:
        set_boundary_key(obj_a, attr, start - 1)
        set_boundary_key(obj_a, attr, start)
        set_boundary_key(obj_a, attr, end)
        set_boundary_key(obj_a, attr, end + 1)
    if has_anim_b:
        set_boundary_key(obj_b, attr, start - 1)
        set_boundary_key(obj_b, attr, start)
        set_boundary_key(obj_b, attr, end)
        set_boundary_key(obj_b, attr, end + 1)
    
    keys_a = get_keys_in_range(obj_a, attr, start, end)
    keys_b = get_keys_in_range(obj_b, attr, start, end)
    all_keys = sorted(set(keys_a + keys_b))
    
    if not all_keys:
        return
    
    values_a = {}
    values_b = {}
    
    for frame in all_keys:
        values_a[frame] = cmds.getAttr(attr_a, t=frame)
        values_b[frame] = cmds.getAttr(attr_b, t=frame)
    
    for frame in all_keys:
        cmds.setKeyframe(attr_a, t=frame, v=values_b[frame])
        cmds.setKeyframe(attr_b, t=frame, v=values_a[frame])


def swap_animation():
    sel = cmds.ls(sl=True)
    if len(sel) != 2:
        cmds.warning("Select exactly 2 objects!")
        return
    
    obj_a, obj_b = sel[0], sel[1]
    
    start, end = get_selected_range()
    if start is None:
        cmds.warning("Select range on timeline or keys in Graph Editor!")
        return
    
    print("Swap: {} <-> {} | Range: {}-{}".format(obj_a, obj_b, start, end))
    
    try:
        cmds.undoInfo(openChunk=True, chunkName="Swap Animation")
        
        for attr in ATTRS:
            swap_attr_in_range(obj_a, obj_b, attr, start, end)
        
        print("Swap complete!")
        
    except Exception as e:
        cmds.warning("Error: {}".format(str(e)))
        raise
        
    finally:
        cmds.undoInfo(closeChunk=True)


if __name__ == "__main__":
    swap_animation()
