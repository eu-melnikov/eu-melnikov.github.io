Quick Save to Temp — Maya 2019+
--------------------------------

A small Python script for Maya. Saves the current scene to a fixed
temp folder in one click — no dialogs, no interruptions.

Done something quick? Don't want to delete it but can't be bothered
finding a place to save? Just hit the button — scene saved.


WHAT IT DOES
------------
- Automatically appends a "_QS" suffix to the filename
- Creates incremental versions: _001, _002, _003...
- Saves instantly with no prompts


KILLER FEATURE
--------------
Working in a brand new scene that has never been saved?
No problem. The script will automatically save it as
"scene_noname_QS.mb" into the QuickSave folder.


PERFECT FOR
-----------
- Temporary saves
- Quick experiments
- Fast backups before trying something risky


SETUP
-----
1. Open the script in Script Editor
2. Set your folder path in this line:
       "e:\WORK\Projects\Temp\QuickSave"
3. Copy to shelf — make sure Python mode is selected
4. A shelf icon is included in the package
