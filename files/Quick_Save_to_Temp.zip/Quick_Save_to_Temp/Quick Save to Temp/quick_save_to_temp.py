"""
Quick Save to Temp
Python 2.7 compatible - Version 1.0
Author: e.melnikov (e.ov)
"""

import maya.cmds as cmds
import maya.mel as mel
import os

def quick_save_to_temp():
    """Quick save to fixed folder with QS suffix and increment"""
    
    # Fixed target folder
    target_folder = r"d:\WORK\Projects\Temp\QuickSave"
    
    # Create folder if it doesn't exist
    if not os.path.exists(target_folder):
        try:
            os.makedirs(target_folder)
        except Exception as e:
            cmds.warning("Cannot create folder: {}".format(str(e)))
            return
    
    # Get current scene name
    current_path = cmds.file(query=True, sceneName=True)
    
    # Get current shading mode from active viewport
    active_panel = cmds.getPanel(withFocus=True)
    if cmds.getPanel(typeOf=active_panel) == 'modelPanel':
        shading_mode = cmds.modelEditor(active_panel, query=True, displayAppearance=True)
        wireframe_on_shaded = cmds.modelEditor(active_panel, query=True, wireframeOnShaded=True)
    else:
        # Fallback to first model panel
        model_panels = cmds.getPanel(type='modelPanel')
        if model_panels:
            active_panel = model_panels[0]
            shading_mode = cmds.modelEditor(active_panel, query=True, displayAppearance=True)
            wireframe_on_shaded = cmds.modelEditor(active_panel, query=True, wireframeOnShaded=True)
        else:
            shading_mode = 'smoothShaded'
            wireframe_on_shaded = False
    
    # Extract base name without path and extension
    if current_path:
        filename = os.path.basename(current_path)
        base_name = os.path.splitext(filename)[0]
    else:
        base_name = "scene_noname"
    
    # Build new name with QS suffix
    new_base_name = base_name + "_QS"
    new_filename = new_base_name + ".mb"
    new_path = os.path.join(target_folder, new_filename)
    
    # Check if file exists and find next available increment
    if os.path.exists(new_path):
        counter = 1
        while True:
            incremented_name = "{}_{}".format(new_base_name, str(counter).zfill(3))
            new_filename = incremented_name + ".mb"
            new_path = os.path.join(target_folder, new_filename)
            if not os.path.exists(new_path):
                break
            counter += 1
    
    # Save the file
    cmds.file(rename=new_path)
    cmds.file(save=True, type='mayaBinary')
    
    # Add to Recent Files using MEL command
    try:
        mel.eval('addRecentFile("{}", "mayaBinary");'.format(new_path.replace('\\', '/')))
    except:
        pass
    
    # Store and apply shading mode
    cmds.optionVar(stringValue=('savedShadingMode', shading_mode))
    cmds.optionVar(intValue=('savedWireframeOnShaded', int(wireframe_on_shaded)))
    
    for panel in cmds.getPanel(type='modelPanel'):
        cmds.modelEditor(panel, edit=True, displayAppearance=shading_mode)
        cmds.modelEditor(panel, edit=True, wireframeOnShaded=wireframe_on_shaded)
    
    cmds.warning("Quick saved as: {}".format(new_path))

quick_save_to_temp()
